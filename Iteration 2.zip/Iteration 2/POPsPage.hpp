#ifndef POPS_PAGE_HPP
#define POPS_PAGE_HPP

#include <QWidget>

class POPsPage : public QWidget
{
    Q_OBJECT

public:
    explicit POPsPage(QWidget* parent = nullptr);

private:

};

#endif 
