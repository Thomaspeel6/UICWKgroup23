#include "PollutantOverviewPage.hpp"

PollutantOverviewPage::PollutantOverviewPage(QWidget* parent)
    : QWidget(parent)
{
  
}
