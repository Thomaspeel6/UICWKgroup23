#ifndef POLLUTANT_OVERVIEW_PAGE_HPP
#define POLLUTANT_OVERVIEW_PAGE_HPP

#include <QWidget>

class PollutantOverviewPage : public QWidget
{
    Q_OBJECT

public:
    explicit PollutantOverviewPage(QWidget* parent = nullptr);

private:

};

#endif 
