#include "POPsPage.hpp"

POPsPage::POPsPage(QWidget* parent)
    : QWidget(parent)
{
  
}
