#include "EnvironmentalLitterIndicatorsPage.hpp"

EnvironmentalLitterIndicatorsPage::EnvironmentalLitterIndicatorsPage(QWidget* parent)
    : QWidget(parent)
{
  
}
