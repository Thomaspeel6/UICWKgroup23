#include "FluorinatedCompoundsPage.hpp"

FluorinatedCompoundsPage::FluorinatedCompoundsPage(QWidget* parent)
    : QWidget(parent)
{
  
}
