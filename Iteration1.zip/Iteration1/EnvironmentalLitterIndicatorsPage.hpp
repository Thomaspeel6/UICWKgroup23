#ifndef ENVIROMENTAL_LITTER_INDICATORS_PAGE_HPP
#define ENVIROMENTAL_LITTER_INDICATORS_PAGE_HPP

#include <QWidget>

class EnvironmentalLitterIndicatorsPage : public QWidget
{
    Q_OBJECT

public:
    explicit EnvironmentalLitterIndicatorsPage(QWidget* parent = nullptr);

private:

};

#endif 
