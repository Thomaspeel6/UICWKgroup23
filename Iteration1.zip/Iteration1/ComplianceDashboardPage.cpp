#include "ComplianceDashboardPage.hpp"

ComplianceDashboardPage::ComplianceDashboardPage(QWidget* parent)
    : QWidget(parent)
{
  
}
