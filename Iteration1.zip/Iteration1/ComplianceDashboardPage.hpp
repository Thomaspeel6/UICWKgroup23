#ifndef COMPLIANCE_DASHBOARD_PAGE_HPP
#define COMPLIANCE_DASHBOARD_PAGE_HPP

#include <QWidget>

class ComplianceDashboardPage : public QWidget
{
    Q_OBJECT

public:
    explicit ComplianceDashboardPage(QWidget* parent = nullptr);

private:

};

#endif 
