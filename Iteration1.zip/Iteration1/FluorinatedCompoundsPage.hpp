#ifndef FLUORINATED_COMPOUNDS_PAGE_HPP
#define FLUORINATED_COMPOUNDS_PAGE_HPP

#include <QWidget>

class FluorinatedCompoundsPage : public QWidget
{
    Q_OBJECT

public:
    explicit FluorinatedCompoundsPage(QWidget* parent = nullptr);

private:

};

#endif 
